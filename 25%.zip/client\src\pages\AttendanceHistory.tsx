import React from 'react';
import { Box, Card, CardContent, Typography, Button } from '@mui/material';

const FeaturePlaceholder: React.FC = () => {
  return (
    <Box sx={{
      padding: '40px',
      minHeight: '80vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      background: '#f8fafc'
    }}>
      <Card sx={{
        maxWidth: 500,
        width: '100%',
        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
        borderRadius: 2,
        textAlign: 'center',
        p: 2
      }}>
        <CardContent>
          <Typography variant="h5" color="error" gutterBottom fontWeight="bold">
            Feature Coming Soon
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            This feature is scheduled for development in a later phase of DormEase.
          </Typography>
          <Button variant="contained" color="primary" onClick={() => window.history.back()}>
            Go Back
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};

export default FeaturePlaceholder;
