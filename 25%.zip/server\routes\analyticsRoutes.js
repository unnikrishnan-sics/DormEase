const express = require('express');
const router = express.Router();

router.all('*', (req, res) => {
    res.status(501).json({
        success: false,
        message: "Feature coming soon in a later phase."
    });
});

module.exports = router;
